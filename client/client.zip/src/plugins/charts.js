import Vue from 'vue';

import 'echarts/lib/component/title';
import 'echarts/lib/component/dataZoom';
import VeLine from 'v-charts/lib/line';

Vue.component(VeLine.name, VeLine);
